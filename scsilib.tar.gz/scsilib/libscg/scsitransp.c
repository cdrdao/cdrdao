/* @(#)scsitransp.c	1.71 00/09/06 Copyright 1988,1995,2000 J. Schilling */
#ifndef lint
static	char sccsid[] =
	"@(#)scsitransp.c	1.71 00/09/06 Copyright 1988,1995,2000 J. Schilling";
#endif
/*
 *	SCSI user level command transport routines (generic part).
 *
 *	Warning: you may change this source, but if you do that
 *	you need to change the _scg_version and _scg_auth* string below.
 *	You may not return "schily" for an SCG_AUTHOR request anymore.
 *	Choose your name instead of "schily" and make clear that the version
 *	string is related to a modified source.
 *
 *	Copyright (c) 1988,1995,2000 J. Schilling
 */
/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <mconfig.h>
#include <stdio.h>
#include <standard.h>
#include <stdxlib.h>
#include <unixstd.h>
#include <errno.h>
#include <timedefs.h>
#include <strdefs.h>
#include <schily.h>

#include <scg/scgcmd.h>
#include <scg/scsireg.h>
#include <scg/scsitransp.h>
#include "scgtimes.h"

/*
 *	Warning: you may change this source, but if you do that
 *	you need to change the _scg_version and _scg_auth* string below.
 *	You may not return "schily" for an SCG_AUTHOR request anymore.
 *	Choose your name instead of "schily" and make clear that the version
 *	string is related to a modified source.
 */
LOCAL	char	_scg_version[]		= "0.4";	/* The global libscg version	*/
LOCAL	char	_scg_auth_schily[]	= "schily";	/* The author for this module	*/

#define	DEFTIMEOUT	20	/* Default timeout for SCSI command transport */

EXPORT	char	*scg_version	__PR((SCSI *scgp, int what));
EXPORT	int	scg__open	__PR((SCSI *scgp, char *device));
EXPORT	int	scg__close	__PR((SCSI *scgp));
EXPORT	BOOL	scg_havebus	__PR((SCSI *scgp, int));
EXPORT	int	scg_initiator_id __PR((SCSI *scgp));
EXPORT	int	scg_isatapi	__PR((SCSI *scgp));
EXPORT	int	scg_reset	__PR((SCSI *scgp, int what));
EXPORT	void	*scg_getbuf	__PR((SCSI *scgp, long));
EXPORT	void	scg_freebuf	__PR((SCSI *scgp));
EXPORT	long	scg_bufsize	__PR((SCSI *scgp, long));
EXPORT	void	scg_setnonstderrs __PR((SCSI *scgp, const char **));
EXPORT	BOOL	scg_yes		__PR((char *));
#ifdef	nonono
LOCAL	void	scg_sighandler	__PR((int));
#endif
EXPORT	int	scg_cmd		__PR((SCSI *scgp));
EXPORT	int	scg_getresid	__PR((SCSI *scgp));
EXPORT	BOOL	scg_cmd_err	__PR((SCSI *scgp));
EXPORT	void	scg_printerr	__PR((SCSI *scgp));
EXPORT	void	scg_fprinterr	__PR((SCSI *scgp, FILE *f));
EXPORT	int	scg_sprinterr	__PR((SCSI *scgp, char *buf, int maxcnt));
EXPORT	void	scg_printcdb	__PR((SCSI *scgp));
EXPORT	int	scg_sprintcdb	__PR((SCSI *scgp, char *buf, int maxcnt));
EXPORT	void	scg_printwdata	__PR((SCSI *scgp));
EXPORT	int	scg_sprintwdata	__PR((SCSI *scgp, char *buf, int maxcnt));
EXPORT	void	scg_printrdata	__PR((SCSI *scgp));
EXPORT	int	scg_sprintrdata	__PR((SCSI *scgp, char *buf, int maxcnt));
EXPORT	void	scg_printresult	__PR((SCSI *scgp));
EXPORT	int	scg_sprintresult __PR((SCSI *scgp, char *buf, int maxcnt));
EXPORT	void	scg_printstatus	__PR((SCSI *scgp));
EXPORT	int	scg_sprintstatus __PR((SCSI *scgp, char *buf, int maxcnt));
EXPORT	void	scg_fprbytes	__PR((FILE *, char *, unsigned char *, int));
EXPORT	void	scg_prbytes	__PR((char *, unsigned char *, int));
EXPORT	int	scg_sprbytes	__PR((char *buf, int maxcnt, char *, unsigned char *, int));
EXPORT	void	scg_fprsense	__PR((FILE *f, unsigned char *, int));
EXPORT	int	scg_sprsense	__PR((char *buf, int maxcnt, unsigned char *, int));
EXPORT	void	scg_prsense	__PR((unsigned char *, int));
EXPORT	int	scg_cmd_status	__PR((SCSI *scgp));
EXPORT	int	scg_sense_key	__PR((SCSI *scgp));
EXPORT	int	scg_sense_code	__PR((SCSI *scgp));
EXPORT	int	scg_sense_qual	__PR((SCSI *scgp));
EXPORT	void	scg_fprintdev	__PR((FILE *, struct scsi_inquiry *));
EXPORT	void	scg_printdev	__PR((struct scsi_inquiry *));
EXPORT	int	scg_printf	__PR((SCSI *scgp, const char *form, ...));
EXPORT	int	scg_errflush	__PR((SCSI *scgp));

/*
 * Return version information for the SCSI transport code.
 * This has been introduced to make it easier to trace down problems
 * in applications.
 *
 * If scgp is NULL, return general library version information.
 * If scgp is != NULL, return version information for the low level transport.
 */
EXPORT char *
scg_version(scgp, what)
	SCSI	*scgp;
	int	what;
{
	if (scgp == (SCSI *)0) {
		switch (what) {

		case SCG_VERSION:
			return (_scg_version);
		/*
		 * If you changed this source, you are not allowed to
		 * return "schily" for the SCG_AUTHOR request.
		 */
		case SCG_AUTHOR:
			return (_scg_auth_schily);
		case SCG_SCCS_ID:
			return (sccsid);
		default:
			return ((char *)0);
		}
	}
	return (SCGO_VERSION(scgp, what));
}

EXPORT int
scg__open(scgp, device)
	SCSI	*scgp;
	char	*device;
{
	int	ret;
	scg_ops_t *ops;
extern	scg_ops_t scg_std_ops;

	scgp->ops = &scg_std_ops;

	if (device && strncmp(device, "REMOTE", 6) == 0) {
		ops = scg_remote();
		if (ops != NULL)
			scgp->ops = ops;
	}

	ret = SCGO_OPEN(scgp, device);
	if (ret < 0)
		return (ret);

	/*
	 * Now make scgp->fd valid if possible.
	 * Note that scg_scsibus(scgp)/scg_target(scgp)/scg_lun(scgp) may have
	 * changed in SCGO_OPEN().
	 */
	scg_settarget(scgp, scg_scsibus(scgp), scg_target(scgp), scg_lun(scgp));
	return (ret);
}

EXPORT int
scg__close(scgp)
	SCSI	*scgp;
{
	return (SCGO_CLOSE(scgp));
}

EXPORT long
scg_bufsize(scgp, amt)
	SCSI	*scgp;
	long	amt;
{
	long	maxdma;

	maxdma = SCGO_MAXDMA(scgp, amt);
	if (amt <= 0 || amt > maxdma)
		amt = maxdma;

	scgp->maxdma = maxdma;
	scgp->maxbuf = amt;

	return (amt);
}

EXPORT void *
scg_getbuf(scgp, amt)
	SCSI	*scgp;
	long	amt;
{
	if (amt <= 0 || amt > scg_bufsize(scgp, amt))
		return ((void *)0);

	return (SCGO_GETBUF(scgp, amt));
}

EXPORT void
scg_freebuf(scgp)
	SCSI	*scgp;
{
	SCGO_FREEBUF(scgp);
}

EXPORT BOOL
scg_havebus(scgp, busno)
	SCSI	*scgp;
	int	busno;
{
	return (SCGO_HAVEBUS(scgp, busno));
}

EXPORT int
scg_initiator_id(scgp)
	SCSI	*scgp;
{
	return (SCGO_INITIATOR_ID(scgp));
}

EXPORT int
scg_isatapi(scgp)
	SCSI	*scgp;
{
	return (SCGO_ISATAPI(scgp));
}

EXPORT int
scg_reset(scgp, what)
	SCSI	*scgp;
	int	what;
{
	return (SCGO_RESET(scgp, what));
}

EXPORT void
scg_setnonstderrs(scgp, vec)
	SCSI	*scgp;
	const char **vec;
{
	scgp->nonstderrs = vec;
}

EXPORT BOOL
scg_yes(msg)
	char	*msg;
{
	char okbuf[10];

	js_printf("%s", msg);
	flush();
	if (getline(okbuf, sizeof(okbuf)) == EOF)
		exit(EX_BAD);
	if(streql(okbuf, "y") || streql(okbuf, "yes") ||
	   streql(okbuf, "Y") || streql(okbuf, "YES"))
		return (TRUE);
	else
		return (FALSE);
}

#ifdef	nonono
LOCAL void
scg_sighandler(sig)
	int	sig;
{
	js_printf("\n");
	if (scsi_running) {
		js_printf("Running command: %s\n", scsi_command);
		js_printf("Resetting SCSI - Bus.\n");
		if (scg_reset(scgp) < 0)
			errmsg("Cannot reset SCSI - Bus.\n");
	}
	if (scg_yes("EXIT ? "))
		exit(sig);
}
#endif

EXPORT int
scg_cmd(scgp)
	SCSI	*scgp;
{
		 int		n;
		 int		ret;
	register struct	scg_cmd	*scmd = scgp->scmd;

	/*
	 * Reset old error messages in scgp->errstr
	 */
	scgp->errptr = scgp->errbeg = scgp->errstr;

	scmd->kdebug = scgp->kdebug;
	if (scmd->timeout == 0 || scmd->timeout < scgp->deftimeout)
		scmd->timeout = scgp->deftimeout;
	if (scgp->disre_disable)
		scmd->flags &= ~SCG_DISRE_ENA;
	if (scgp->noparity)
		scmd->flags |= SCG_NOPARITY;

	scmd->u_sense.cmd_sense[0] = 0;		/* Paranioa */

	if (scgp->verbose) {
		scg_printf(scgp,
			"\nExecuting '%s' command on Bus %d Target %d, Lun %d timeout %ds\n",
									/* XXX Really this ??? */
/*			scgp->cmdname, scg_scsibus(scgp), scg_target(scgp), scmd->cdb.g0_cdb.lun,*/
			scgp->cmdname, scg_scsibus(scgp), scg_target(scgp), scg_lun(scgp),
			scmd->timeout);
		scgp->errptr += scg_sprintcdb(scgp, scgp->errptr, scg_errrsize(scgp));
		if (scgp->verbose > 1)
			scgp->errptr += scg_sprintwdata(scgp, scgp->errptr, scg_errrsize(scgp));
		scg_errflush(scgp);
	}

	if (scgp->running) {
		if (scgp->curcmdname) {
			error("Currently running '%s' command.\n",
							scgp->curcmdname);
		}
		raisecond("SCSI ALREADY RUNNING !!", 0L);
	}
	gettimeofday(scgp->cmdstart, (struct timezone *)0);
	scgp->curcmdname = scgp->cmdname;
	scgp->running = TRUE;
	ret = SCGO_SEND(scgp);
	scgp->running = FALSE;
	__scg_times(scgp);
	if (ret < 0) {
		/*
		 * Old /dev/scg versions will not allow to access targets > 7.
		 * Include a workaround to make this non fatal.
		 */
		if (scg_target(scgp) < 8 || geterrno() != EINVAL)
			comerr("Cannot send SCSI cmd via ioctl\n");
		if (scmd->ux_errno == 0)
			scmd->ux_errno = geterrno();
		if (scmd->error == SCG_NO_ERROR)
			scmd->error = SCG_FATAL;
		if (scgp->debug) {
			errmsg("ret < 0 errno: %d ux_errno: %d error: %d\n",
					geterrno(), scmd->ux_errno, scmd->error);
		}
	}

	ret = scg_cmd_err(scgp) ? -1 : 0;
	if (ret) {
		if (scgp->silent <= 0 || scgp->verbose) {
			n = scg_sprinterr(scgp, scgp->errptr, scg_errrsize(scgp));
			if (n >= 0)
				scgp->errptr += n;
		}
	}
	if ((scgp->silent <= 0 || scgp->verbose) && scgp->scmd->resid) {
		n = js_snprintf(scgp->errptr, scg_errrsize(scgp),
				"resid: %d\n", scgp->scmd->resid);
		if (n >= 0)
			scgp->errptr += n;
	}
	if (scgp->verbose || (ret && scgp->silent <= 0)) {
		scgp->errptr += scg_sprintresult(scgp, scgp->errptr, scg_errrsize(scgp));
	}
	scg_errflush(scgp);
	return (ret);
}

EXPORT int
scg_getresid(scgp)
	SCSI	*scgp;
{
	return (scgp->scmd->resid);
}

EXPORT BOOL
scg_cmd_err(scgp)
	SCSI	*scgp;
{
	register struct scg_cmd *cp = scgp->scmd;

	if(cp->error != SCG_NO_ERROR ||
				cp->ux_errno != 0 ||
				*(Uchar *)&cp->scb != 0 ||
				cp->u_sense.cmd_sense[0] != 0)	/* Paranioa */
		return (TRUE);
	return (FALSE);
}

/*
 * Used to print error messges if the command itself has been run silently.
 */
EXPORT void
scg_printerr(scgp)
	SCSI	*scgp;
{
	scg_fprinterr(scgp, (FILE *)scgp->errfile);
}

EXPORT void
scg_fprinterr(scgp, f)
	SCSI	*scgp;
	FILE	*f;
{
	char	errbuf[SCSI_ERRSTR_SIZE];
	int	amt;

	amt = scg_sprinterr(scgp, errbuf, sizeof(errbuf));
	if (amt > 0) {
		filewrite(f, errbuf, amt);
		fflush(f);
	}
}

EXPORT int
scg_sprinterr(scgp, buf, maxcnt)
	SCSI	*scgp;
	char	*buf;
	int	maxcnt;
{
	register struct scg_cmd *cp = scgp->scmd;
	register char	*err;
		 char	*cmdname = "SCSI command name not set by caller";
		 char	errbuf[64];
	register char		*p = buf;
	register int		amt;

	switch (cp->error) {

	case SCG_NO_ERROR :	err = "no error"; break;
	case SCG_RETRYABLE:	err = "retryable error"; break;
	case SCG_FATAL    :	err = "fatal error"; break;
				/*
				 * We need to cast timeval->* to long because
				 * of the broken sys/time.h in Linux.
				 */
	case SCG_TIMEOUT  :	js_snprintf(errbuf, sizeof(errbuf),
					"cmd timeout after %ld.%03ld (%d) s",
					(long)scgp->cmdstop->tv_sec,
					(long)scgp->cmdstop->tv_usec/1000,
								cp->timeout);
				err = errbuf;
				break;
	default:		js_snprintf(errbuf, sizeof(errbuf),
					"error: %d", cp->error);
				err = errbuf;
	}

	if (scgp->cmdname != NULL && scgp->cmdname[0] != '\0')
		cmdname = scgp->cmdname;
	amt = serrmsgno(cp->ux_errno, p, maxcnt, "%s: scsi sendcmd: %s\n", cmdname, err);
	if (amt < 0)
		return (amt);
	p += amt;
	maxcnt -= amt;

	amt = scg_sprintcdb(scgp, p, maxcnt);
	if (amt < 0)
		return (amt);
	p += amt;
	maxcnt -= amt;

	if (cp->error <= SCG_RETRYABLE) {
		amt = scg_sprintstatus(scgp, p, maxcnt);
		if (amt < 0)
			return (amt);
		p += amt;
		maxcnt -= amt;
	}

	if (cp->scb.chk) {
		amt = scg_sprsense(p, maxcnt, (Uchar *)&cp->sense, cp->sense_count);
		if (amt < 0)
			return (amt);
		p += amt;
		maxcnt -= amt;
		amt = scg__errmsg(scgp, p, maxcnt, &cp->sense, &cp->scb, -1);
		if (amt < 0)
			return (amt);
		p += amt;
		maxcnt -= amt;
	}
	return (p - buf);
}

/*
 * XXX Do we need this function?
 */
EXPORT void
scg_printcdb(scgp)
	SCSI	*scgp;
{
	scg_prbytes("CDB: ", scgp->scmd->cdb.cmd_cdb, scgp->scmd->cdb_len);
}

EXPORT int
scg_sprintcdb(scgp, buf, maxcnt)
	SCSI	*scgp;
	char	*buf;
	int	maxcnt;
{
	int	cnt;

	cnt = scg_sprbytes(buf, maxcnt, "CDB: ", scgp->scmd->cdb.cmd_cdb, scgp->scmd->cdb_len);
	if (cnt < 0)
		cnt = 0;
	return (cnt);
}

/*
 * XXX Do we need this function?
 * XXX scg_printrdata() is used.
 * XXX We need to check if we should write to stderr or better to scg->errfile
 */
EXPORT void
scg_printwdata(scgp)
	SCSI	*scgp;
{
	register struct	scg_cmd	*scmd = scgp->scmd;

	if (scmd->size > 0 && (scmd->flags & SCG_RECV_DATA) == 0) {
		js_fprintf(stderr, "Sending %d (0x%X) bytes of data.\n",
			scmd->size, scmd->size);
		scg_prbytes("Write Data: ",
			(Uchar *)scmd->addr,
			scmd->size > 100 ? 100 : scmd->size);
	}
}

EXPORT int
scg_sprintwdata(scgp, buf, maxcnt)
	SCSI	*scgp;
	char	*buf;
	int	maxcnt;
{
	register struct	scg_cmd	*scmd = scgp->scmd;
	register char		*p = buf;
	register int		amt;

	if (scmd->size > 0 && (scmd->flags & SCG_RECV_DATA) == 0) {
		amt = js_snprintf(p, maxcnt,
			"Sending %d (0x%X) bytes of data.\n",
			scmd->size, scmd->size);
		if (amt < 0)
			return (amt);
		p += amt;
		maxcnt -= amt;
		amt = scg_sprbytes(p, maxcnt, "Write Data: ",
			(Uchar *)scmd->addr,
			scmd->size > 100 ? 100 : scmd->size);
		if (amt < 0)
			return (amt);
		p += amt;
	}
	return (p - buf);
}

/*
 * XXX We need to check if we should write to stderr or better to scg->errfile
 */
EXPORT void
scg_printrdata(scgp)
	SCSI	*scgp;
{
	register struct	scg_cmd	*scmd = scgp->scmd;

	if (scmd->size > 0 && (scmd->flags & SCG_RECV_DATA) != 0) {
		js_fprintf(stderr, "Got %d (0x%X), expecting %d (0x%X) bytes of data.\n",
			scmd->size-scmd->resid, scmd->size-scmd->resid,
			scmd->size, scmd->size);
		scg_prbytes("Received Data: ",
			(Uchar *)scmd->addr,
			(scmd->size-scmd->resid) > 100 ?
			100 : (scmd->size-scmd->resid));
	}
}

EXPORT int
scg_sprintrdata(scgp, buf, maxcnt)
	SCSI	*scgp;
	char	*buf;
	int	maxcnt;
{
	register struct	scg_cmd	*scmd = scgp->scmd;
	register char		*p = buf;
	register int		amt;

	if (scmd->size > 0 && (scmd->flags & SCG_RECV_DATA) != 0) {
		amt = js_snprintf(p, maxcnt,
			"Got %d (0x%X), expecting %d (0x%X) bytes of data.\n",
			scmd->size-scmd->resid, scmd->size-scmd->resid,
			scmd->size, scmd->size);
		if (amt < 0)
			return (amt);
		p += amt;
		maxcnt -= amt;
		amt = scg_sprbytes(p, maxcnt,
			"Received Data: ",
			(Uchar *)scmd->addr,
			(scmd->size-scmd->resid) > 100 ?
			100 : (scmd->size-scmd->resid));
		if (amt < 0)
			return (amt);
		p += amt;
	}
	return (p - buf);
}

/*
 * XXX We need to check if we should write to stderr or better to scg->errfile
 */
EXPORT void
scg_printresult(scgp)
	SCSI	*scgp;
{
	js_fprintf(stderr, "cmd finished after %ld.%03lds timeout %ds\n",
		(long)scgp->cmdstop->tv_sec,
		(long)scgp->cmdstop->tv_usec/1000,
		scgp->scmd->timeout);
	if (scgp->verbose > 1)
		scg_printrdata(scgp);
	flush();
}

EXPORT int
scg_sprintresult(scgp, buf, maxcnt)
	SCSI	*scgp;
	char	*buf;
	int	maxcnt;
{
	register char		*p = buf;
	register int		amt;

	amt = js_snprintf(p, maxcnt,
		"cmd finished after %ld.%03lds timeout %ds\n",
		(long)scgp->cmdstop->tv_sec,
		(long)scgp->cmdstop->tv_usec/1000,
		scgp->scmd->timeout);
	if (amt < 0)
		return (amt);
	p += amt;
	maxcnt -= amt;
	if (scgp->verbose > 1) {
		amt = scg_sprintrdata(scgp, p, maxcnt);
		if (amt < 0)
			return (amt);
		p += amt;
	}
	return (p - buf);
}

/*
 * XXX Do we need this function?
 */
EXPORT void
scg_printstatus(scgp)
	SCSI	*scgp;
{
	char	errbuf[SCSI_ERRSTR_SIZE];
	int	amt;

	amt = scg_sprintstatus(scgp, errbuf, sizeof(errbuf));
	if (amt > 0) {
		filewrite((FILE *)scgp->errfile, errbuf, amt);
		fflush((FILE *)scgp->errfile);
	}
}

EXPORT int
scg_sprintstatus(scgp, buf, maxcnt)
	SCSI	*scgp;
	char	*buf;
	int	maxcnt;
{
	register struct scg_cmd *cp = scgp->scmd;
		 char	*err;
		 char	*err2 = "";
	register char	*p = buf;
	register int	amt;

	amt = js_snprintf(p, maxcnt, "status: 0x%x ", *(Uchar *)&cp->scb);
	if (amt < 0)
		return (amt);
	p += amt;
	maxcnt -= amt;
#ifdef	SCSI_EXTENDED_STATUS
	if (cp->scb.ext_st1) {
		amt = js_snprintf(p, maxcnt, "0x%x ", ((Uchar *)&cp->scb)[1]);
		if (amt < 0)
			return (amt);
		p += amt;
		maxcnt -= amt;
	}
	if (cp->scb.ext_st2) {
		amt = js_snprintf(p, maxcnt, "0x%x ", ((Uchar *)&cp->scb)[2]);
		if (amt < 0)
			return (amt);
		p += amt;
		maxcnt -= amt;
	}
#endif
	switch (*(Uchar *)&cp->scb & 036) {

	case 0  : err = "GOOD STATUS";			break;
	case 02 : err = "CHECK CONDITION";		break;
	case 04 : err = "CONDITION MET/GOOD";		break;
	case 010: err = "BUSY";				break;
	case 020: err = "INTERMEDIATE GOOD STATUS";	break;
	case 024: err = "INTERMEDIATE CONDITION MET/GOOD"; break;
	case 030: err = "RESERVATION CONFLICT";		break;
	default : err = "Reserved";			break;
	}
#ifdef	SCSI_EXTENDED_STATUS
	if (cp->scb.ext_st1 && cp->scb.ha_er)
		err2 = " host adapter detected error";
#endif
	amt = js_snprintf(p, maxcnt, "(%s%s)\n", err, err2);
	if (amt < 0)
		return (amt);
	p += amt;
	return (p - buf);
}

EXPORT void
scg_fprbytes(f, s, cp, n)
		FILE	*f;
		char	*s;
	register Uchar	*cp;
	register int	n;
{
	js_fprintf(f, s);
	while (--n >= 0)
		js_fprintf(f, " %02X", *cp++);
	js_fprintf(f, "\n");
}

/*
 * XXX We need to check if we should write to stderr or better to scg->errfile
 */
EXPORT void
scg_prbytes(s, cp, n)
		char	*s;
	register Uchar	*cp;
	register int	n;
{
	scg_fprbytes(stderr, s, cp, n);
}

EXPORT int
scg_sprbytes(buf, maxcnt, s, cp, n)
		char	*buf;
		int	maxcnt;
		char	*s;
	register Uchar	*cp;
	register int	n;
{
	register char	*p = buf;
	register int	amt;

	amt = js_snprintf(p, maxcnt, s);
	if (amt < 0)
		return (amt);
	p += amt;
	maxcnt -= amt;

	while (--n >= 0) {
		amt = js_snprintf(p, maxcnt, " %02X", *cp++);
		if (amt < 0)
			return (amt);
		p += amt;
		maxcnt -= amt;
	}
	amt = js_snprintf(p, maxcnt, "\n");
	if (amt < 0)
		return (amt);
	p += amt;
	return (p - buf);
}

EXPORT void
scg_fprsense(f, cp, n)
	FILE	*f;
	Uchar	*cp;
	int	n;
{
	scg_fprbytes(f, "Sense Bytes:", cp, n);
}

/*
 * XXX We need to check if we should write to stderr or better to scg->errfile
 */
EXPORT void
scg_prsense(cp, n)
	Uchar	*cp;
	int	n;
{
	scg_fprsense(stderr, cp, n);
}

EXPORT int
scg_sprsense(buf, maxcnt, cp, n)
	char	*buf;
	int	maxcnt;
	Uchar	*cp;
	int	n;
{
	return (scg_sprbytes(buf, maxcnt, "Sense Bytes:", cp, n));
}

EXPORT int
scg_cmd_status(scgp)
	SCSI	*scgp;
{
	struct scg_cmd	*cp = scgp->scmd;
	int		cmdstatus = *(Uchar *)&cp->scb;

	return (cmdstatus);
}

EXPORT int
scg_sense_key(scgp)
	SCSI	*scgp;
{
	register struct scg_cmd *cp = scgp->scmd;
	int	key = -1;

	if(!scg_cmd_err(scgp))
		return (0);

	if (cp->sense.code >= 0x70)
		key = ((struct scsi_ext_sense*)&(cp->sense))->key;
	return (key);
}

EXPORT int
scg_sense_code(scgp)
	SCSI	*scgp;
{
	register struct scg_cmd *cp = scgp->scmd;
	int	code = -1;

	if(!scg_cmd_err(scgp))
		return (0);

	if (cp->sense.code >= 0x70)
		code = ((struct scsi_ext_sense*)&(cp->sense))->sense_code;
	else
		code = cp->sense.code;
	return (code);
}

EXPORT int
scg_sense_qual(scgp)
	SCSI	*scgp;
{
	register struct scg_cmd *cp = scgp->scmd;

	if(!scg_cmd_err(scgp))
		return (0);

	if (cp->sense.code >= 0x70)
		return (((struct scsi_ext_sense*)&(cp->sense))->qual_code);
	else
		return (0);
}

EXPORT void
scg_fprintdev(f, ip)
		FILE	*f;
	struct	scsi_inquiry *ip;
{
	if (ip->removable)
		js_fprintf(f, "Removable ");
	if (ip->data_format >= 2) {
		switch (ip->qualifier) {

		case INQ_DEV_PRESENT:
			break;
		case INQ_DEV_NOTPR:
			js_fprintf(f, "not present ");
			break;
		case INQ_DEV_RES:
			js_fprintf(f, "reserved ");
			break;
		case INQ_DEV_NOTSUP:
			if (ip->type == INQ_NODEV) {
				js_fprintf(f, "unsupported\n"); return;
			}
			js_fprintf(f, "unsupported ");
			break;
		default:
			js_fprintf(f, "vendor specific %d ", ip->qualifier);
		}
	}
	switch (ip->type) {

	case INQ_DASD:
		js_fprintf(f, "Disk");		break;
	case INQ_SEQD:
		js_fprintf(f, "Tape");		break;
	case INQ_PRTD:
		js_fprintf(f, "Printer");	break;
	case INQ_PROCD:
		js_fprintf(f, "Processor");	break;
	case INQ_WORM:
		js_fprintf(f, "WORM");		break;
	case INQ_ROMD:
		js_fprintf(f, "CD-ROM");	break;
	case INQ_SCAN:
		js_fprintf(f, "Scanner");	break;
	case INQ_OMEM:
		js_fprintf(f, "Optical Storage");break;
	case INQ_JUKE:
		js_fprintf(f, "Juke Box");	break;
	case INQ_COMM:
		js_fprintf(f, "Communication");	break;
	case INQ_IT8_1:
		js_fprintf(f, "IT8 1");		break;
	case INQ_IT8_2:
		js_fprintf(f, "IT8 2");		break;
	case INQ_STARR:
		js_fprintf(f, "Storage array");	break;
	case INQ_ENCL:
		js_fprintf(f, "Enclosure services");break;

	case INQ_NODEV:
		if (ip->data_format >= 2) {
			js_fprintf(f, "unknown/no device");
			break;
		} else if (ip->qualifier == INQ_DEV_NOTSUP) {
			js_fprintf(f, "unit not present");
			break;
		}
	default:
		js_fprintf(f, "unknown device type 0x%x", ip->type);
	}
	js_fprintf(f, "\n");
}

EXPORT void
scg_printdev(ip)
	struct	scsi_inquiry *ip;
{
	scg_fprintdev(stdout, ip);
}

#include <vadefs.h>

/* VARARGS2 */
EXPORT int
#ifdef	PROTOTYPES
scg_printf(SCSI *scgp, const char *form, ...)
#else
scg_printf(scgp, form, va_alist)
	SCSI	*scgp;
	char	*form;
	va_dcl
#endif
{
	int	cnt;
	va_list	args;

#ifdef	PROTOTYPES
	va_start(args, form);
#else
	va_start(args);
#endif
	cnt = js_snprintf(scgp->errptr, scg_errrsize(scgp), "%r", form, args);
	va_end(args);

	if (cnt < 0) {
		scgp->errptr[0] = '\0';
	} else {
		scgp->errptr += cnt;
	}
	return (cnt);
}

EXPORT int
scg_errflush(scgp)
	SCSI	*scgp;
{
	int	cnt;

	if (scgp->errfile == NULL)
		return (0);

	cnt = scgp->errptr - scgp->errbeg;
	if (cnt > 0) {
		filewrite((FILE *)scgp->errfile, scgp->errbeg, cnt);
		fflush((FILE *)scgp->errfile);
		scgp->errbeg = scgp->errptr;
	}
	return (cnt);
}
